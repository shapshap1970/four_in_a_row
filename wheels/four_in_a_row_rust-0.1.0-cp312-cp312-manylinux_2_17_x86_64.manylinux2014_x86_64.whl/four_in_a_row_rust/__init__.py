from .four_in_a_row_rust import *

__doc__ = four_in_a_row_rust.__doc__
if hasattr(four_in_a_row_rust, "__all__"):
    __all__ = four_in_a_row_rust.__all__